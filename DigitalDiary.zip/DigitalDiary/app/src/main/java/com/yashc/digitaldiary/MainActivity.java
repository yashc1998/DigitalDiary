package com.yashc.digitaldiary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;

import com.yashc.digitaldiary.adapter.NotesAdapter;
import com.yashc.digitaldiary.db.DatabaseClient;
import com.yashc.digitaldiary.modal.Note;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView mNotesRecyclerView;
    private NotesAdapter mNotesAdapter = null;
    private Toolbar mMainToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mMainToolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(mMainToolbar);

        if(mMainToolbar != null){
            mMainToolbar.setTitle("Digital Diary");
            mMainToolbar.setTitleTextColor(Color.BLACK);
            getSupportActionBar().setElevation(5.0f);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                mMainToolbar.setElevation(5.0f);
            }
        }

        //Initialising the recycler view
        mNotesRecyclerView = findViewById(R.id.notes_rv);

        mNotesRecyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        mNotesRecyclerView.setHasFixedSize(true);

        getAllNotes();
    }

    private void getAllNotes() {

        class GetNotes extends AsyncTask<Void, Void, List<Note>>{

            @Override
            protected List<Note> doInBackground(Void... voids) {
                List<Note> notes = DatabaseClient.getDatabaseInstance(MainActivity.this)
                        .getAppDatabase()
                        .noteDao()
                        .getAllNotes();
                return notes;
            }

            @Override
            protected void onPostExecute(List<Note> notes) {
                super.onPostExecute(notes);
                mNotesAdapter = new NotesAdapter(getDummyData(), MainActivity.this);
                mNotesRecyclerView.setAdapter(mNotesAdapter);
            }
        }

        GetNotes getNotes = new GetNotes();
        getNotes.execute();
    }

    public List<Note> getDummyData(){
        List<Note> notes = new ArrayList<>();
        notes.add(new Note(0, "Test1", "Something happening", "3 sec ago"));
        notes.add(new Note(1, "Test is happening", "Something happening", "3 sec ago"));
        notes.add(new Note(2, "So whats happening", "Something happening", "3 sec ago"));
        notes.add(new Note(3, "What is this", "Something happening", "3 sec ago"));
        notes.add(new Note(4, "Its Raining outside", "Something happening", "3 sec ago"));
        notes.add(new Note(5, "This is amazing", "Something happening", "3 sec ago"));

        return notes;
    }
}
