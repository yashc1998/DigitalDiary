package com.yashc.digitaldiary.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.yashc.digitaldiary.NotesDetail;
import com.yashc.digitaldiary.R;
import com.yashc.digitaldiary.modal.Note;

import java.util.ArrayList;
import java.util.List;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.NotesHolder> {

    private List<Note> mNotesList;
    private Context mCtx;

    public NotesAdapter(List<Note> mNotesList, Context mCtx) {
        this.mNotesList = mNotesList;
        this.mCtx = mCtx;
    }

    @NonNull
    @Override
    public NotesHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new NotesHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_note, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull NotesHolder holder, int position) {
        Note note = mNotesList.get(position);
        holder.notesTitle.setText(note.getTitle());
        holder.lastModified.setText("Last Modified: " + note.getLastModified());
    }

    @Override
    public int getItemCount() {
        return mNotesList.size();
    }

    class NotesHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener {

        TextView notesTitle;
        TextView lastModified;

        public NotesHolder(View itemView){
            super(itemView);

            notesTitle = itemView.findViewById(R.id.item_note_title);
            lastModified = itemView.findViewById(R.id.item_note_last_modified);

            itemView.setOnClickListener(this);
            itemView.setOnLongClickListener(this);
        }

        @Override
        public void onClick(View view) {
            Note note = mNotesList.get(getAdapterPosition());
            Intent intent = new Intent(mCtx, NotesDetail.class);
            intent.putExtra("EXTRA_NOTE", note);
            mCtx.startActivity(intent);
        }


        @Override
        public boolean onLongClick(View view) {
            Note note = mNotesList.get(getAdapterPosition());
            Toast.makeText(mCtx, note.getTitle() + " clicked", Toast.LENGTH_SHORT).show();
            return true;
        }
    }
}
