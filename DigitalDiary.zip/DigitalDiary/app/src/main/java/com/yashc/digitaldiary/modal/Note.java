package com.yashc.digitaldiary.modal;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;
import java.sql.Date;

@Entity
public class Note implements Serializable {
    @PrimaryKey(autoGenerate = true)
    private int mId;

    @ColumnInfo(name = "title")
    private String mTitle;

    @ColumnInfo(name = "content")
    private String mContent;

    @ColumnInfo(name = "last_modified")
    private String mLastModified;

    public Note(int mId, String mTitle, String mContent, String mLastModified) {
        this.mId = mId;
        this.mTitle = mTitle;
        this.mContent = mContent;
        this.mLastModified = mLastModified;
    }

    public int getId() {
        return mId;
    }

    public void setId(int mId) {
        this.mId = mId;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String mTitle) {
        this.mTitle = mTitle;
    }

    public String getContent() {
        return mContent;
    }

    public void setContent(String mContent) {
        this.mContent = mContent;
    }

    public String getLastModified() {
        return mLastModified;
    }

    public void setLastModified(String mLastModified) {
        this.mLastModified = mLastModified;
    }
}
